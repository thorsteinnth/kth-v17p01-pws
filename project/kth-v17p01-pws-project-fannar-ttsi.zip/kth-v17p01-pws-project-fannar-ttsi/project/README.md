#KTH V17P01 Programming Web Services - Project
Due 17.03.06 23:59

Fannar Magnusson (fannar@kth.se) & Thorsteinn Thorri Sigurdsson (ttsi@kth.se)

The project uses the Predic8 library for WSDL parsing (http://www.membrane-soa.org/soa-model/). All JARs are included in the deliverable.

Generated output files will be placed in the output_xml directory.

The project is delivered as an IntelliJ project. We meant to deliver it as a Gradle project, however we were having issues with getting the dependency for com.sun.xml.internal.bind.namespacePrefixMapper which we use to format the output XMLs.



