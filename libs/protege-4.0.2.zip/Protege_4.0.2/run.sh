#!/bin/sh

java ${CMD_OPTIONS} -Xmx200M -Dosgi.clean=true -DentityExpansionLimit=100000000 -Dfile.encoding=utf-8 -jar org.eclipse.osgi.jar
