To generate a sample diff report for WSDL:

1. run the 'wsdl-sample-diff.bat' with a doble click
2. go to 'wsdl-diff-output' and open 'diff-report.html'




To generate a sample diff report for XSD Schema:

1. run the 'schema-sample-diff.bat' with a doble click
2. go to 'schema-diff-output' and open 'diff-report.html'